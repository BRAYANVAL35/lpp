package proyecto.inicio;
import java.io.*;
public class ProyectoInicio 
{

    public static void main(String[] args)
    {
        int n1,n2,n3,resultado;
        int num1=10,num2=17,num3;
            System.out.print ("suma de variables \n");
            resultado=num1+num2;
            System.out.print ("la respueta es: "+resultado);
    }
    
}
