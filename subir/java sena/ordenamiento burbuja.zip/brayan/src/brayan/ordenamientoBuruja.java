package brayan;

import java.util.Scanner;
public class ordenamientoBuruja {
      
     public static void main(String[] args) 
     {  
       /*String palabra1 = "el fin de la imagen \n";
       String palabra2 = "como helado \n";
       System.out.print (palabra1+palabra2);*/ 
         
         
        /*char cuco;
        cuco=' ';
        System.out.println("digite el caracter ");
        Scanner lulo = new Scanner (System.in);
        cuco = lulo.next().charAt(0);
        System.out.println("su caracter es: "+ cuco );*/ 
       
        /*int numero1=pichona.nextInt();
        int numero2=pichona.nextInt();
        
         do{
          System.out.println("error el segundo numero debe ser mayor que el primero ");
          numero2=pichona.nextInt();
           }
         while (numero2<=numero1);
         do{
            System.out.println( numero1);
            numero1++;
           }
         while (numero1<=numero2); */ 
       
        /*Scanner sc = new Scanner (System.in);
        String nombre,apellido; 
        System.out.println ("aplicativo para mostrar tus nmbres y aapellidos \n");
        System.out.print ("\n ingresa tu nombre: ");
        nombre=sc.nextLine();
        System.out.print (" \n ingresa tu apellido: ");
        apellido = sc.nextLine();
        System.out.print (" tu nombe es: "+nombre+" tu apellido es: "+apellido+"\n");*/
         
        /* for (int i = 0; i < 5; i++) {
             
             System.out.println("DESPERTAR!"+i+"\n"); */
          
         
         int vector[];
         vector = new int[6];
         int i,j,k,h,aux,cantidad;
         Scanner sc = new Scanner (System.in);
                  
         System.out.println ("ordenando numeros de forma descendente \n");
         System.out.println("ingrese la cantidad de datos a ordenar: ");  
         cantidad=sc.nextInt();
         for ( i = 0; i < cantidad; i++) {
               
             System.out.print("numero: ");
            vector[i]=sc.nextInt();
             System.out.println();
 
         }
         
         for (i = 0; i < cantidad; i++) 
         {
             for ( j = i+1; j < cantidad; j++) 
             {
                 if (vector[j]>vector[i]) {
                     
                     aux=vector[j];
                     vector[j]=vector[i];
                     vector[i]=vector[j];
                     vector[i]=aux;
                             
                     
                 }
             }
             
         }
         System.out.println("\n Descendentes: ");
         for (i=0;i<cantidad; i++) {
             
              System.out.println("la posicion "+(i+1)+" es: "+vector[i]);
             
         }
         System.out.println("\n Acendentes: ");
         for (i=(cantidad-1);i>=0; i--) {
             
              System.out.println("la posicion "+(i+1)+" es: "+vector[i]); 
         }
        
     }
}
