package brayan;
import java.util.Scanner;
public class Brayan 
{
    public static void main(String[] args) 
    {
        Scanner pichon=new Scanner(System.in);
        System.out.println("t.n.t");
        int numero1=pichon.nextInt();
        System.out.println("t.n.t");
        int numero2=pichon.nextInt();
        int n1=1,n2=1;
        
        while(numero2<=numero1)
        {
            
            while(n1<=9)
            {
                System.out.println(n1);
                n1=n1+2;
            }
            /*System.out.println("error el segundo numero tiene que ser mayor que el primero");
            numero2=pichon.nextInt();*/
            
        }
        while(numero1<=numero2)
        {
            while(n1<=10)
            { 
                System.out.println(n1);
                n1=n1+1;
                
            }
        }
    }
}