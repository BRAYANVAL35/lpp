

package brayan;
public class lol {
    int contador = 0;
int incremento = 1;
 
while (contador !=100) 
{		  
  if (esImpar(incremento)) {
    System.out.println(incremento);
    contador++;
  }			
  incremento++;  
}
    
}
