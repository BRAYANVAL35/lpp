package brayan;
import java.util.Scanner;
public class matriz 
{
public static void main(String[] args) 
    {
            Scanner a=new Scanner(System.in);
            int cantidad[][]=new int[5][5];
            for(int i=0;i<4;i++)
            {
                    for (int j=0;j<4;j++)
                    {
                            System.out.print ("digite un numero["+i+"]["+j+"]\n");
                            cantidad[i][j]= a.nextInt();
                    }
            }
        
        
        
//        int cantidad[][]=new int[5][5];
//        cantidad[0][0]=1;
//        cantidad[0][1]=2;
//        cantidad[0][2]=3;
//        cantidad[0][3]=4;
//        cantidad[1][0]=5;
//        cantidad[1][1]=6;
//        cantidad[1][2]=7;
//        cantidad[1][3]=8;
//        cantidad[2][0]=9;
//        cantidad[2][1]=10;
//        cantidad[2][2]=11;
//        cantidad[2][3]=12;
//        cantidad[3][0]=13;
//        cantidad[3][1]=14;
//        cantidad[3][2]=15;
//        cantidad[3][3]=16;
//                        
//                      
            System.out.println ("\t\t\t"+"imprimiendo..."+"\n"+"=================================================================");
            for (int i=0;i<4;i++)
            {
                    for (int j=0;j<4;j++)
                    {
                            //cout<<"["<<i<<"]["<<j<<"]\n";
                            System.out.print("|");
                            System.out.print("\t"+cantidad[i][j]+"\t");
                            System.out.print("|");
                    }

                    System.out.println("");
            }
            System.out.print("=================================================================");
            System.out.println("\nmatriz transpuesta"+"\n"+"================================================================="+"\n");
            for (int i=0;i<4;i++)
                    {
                            for (int j=0;j<4;j++)
                            {
                                    System.out.print("|");
                                    System.out.print("\t"+cantidad[j][i]+"\t");
                                    System.out.print("|");
                            }
                            System.out.println("");

                    }
            System.out.print("================================================================="+"\n");	
    }
    
}
