package brayan;

import java.util.Scanner;
public class ordenamientoBuruja {
      
     public static void main(String[] args) 
     {   
         int vector[];
         vector = new int[6];
         int i,j,k,h,aux,cantidad;
         Scanner sc = new Scanner (System.in);
                  
         System.out.println ("ordenando numeros de forma descendente \n");
         System.out.println("ingrese la cantidad de datos a ordenar: ");  
         cantidad=sc.nextInt();
         for ( i = 0; i < cantidad; i++) {
               
             System.out.print("numero: ");
            vector[i]=sc.nextInt();
             System.out.println();
 
         }
         
         for (i = 0; i < cantidad; i++) 
         {
             for ( j = i+1; j < cantidad; j++) 
             {
                 if (vector[j]>vector[i]) {
                     
                     aux=vector[j];
                     vector[j]=vector[i];
                     vector[i]=vector[j];
                     vector[i]=aux;
                             
                     
                 }
             }
             
         }
         System.out.println("\n Descendentes: ");
         for (i=0;i<cantidad; i++) {
             
              System.out.println("la posicion "+(i+1)+" es: "+vector[i]);
             
         }
         System.out.println("\n Acendentes: ");
         for (i=(cantidad-1);i>=0; i--) {
             
              System.out.println("la posicion "+(i+1)+" es: "+vector[i]); 
         }
        
     }
}
