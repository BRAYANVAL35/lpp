package brayan;
import java.util.Scanner;
public class string 
{
    public static void main(String[] args) 
    {
        Scanner sc=new Scanner(System.in);
        String nombre,apellido;
        System.out.println("aplicativo para ingresar tus nombres y apellidos\n");
        System.out.println("ingresa tu nombre");
        nombre=sc.nextLine();
        System.out.println("\n ingresa tu appellido");
        apellido=sc.nextLine();
        System.out.println("tu nombre es: "+nombre+" y tu apellido es: "+apellido);
    }
    
}
