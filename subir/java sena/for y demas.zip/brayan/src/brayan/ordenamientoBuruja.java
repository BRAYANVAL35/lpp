package brayan;

public class ordenamientoBuruja
{
      public static void main(String[] args) 
      {
          int f,c,a;
          int vector [];
          vector=new int[5];
          
          vector[1]=25;
          vector[2]=9;
          vector[3]=37;
          vector[4]=1;
          vector[5]=13;
          
          System.out.println("los vectores en orden son:");
          for (f=1;f<=5;f++)
          {
              System.out.println(vector[f]);
          }
          for (f=1;f<=5;f++)
          {
              for (c=1;f<=5;f++)
              {
                  if (vector[c]>vector[c+1])
                  {
                      a=vector[c];
                      vector[c]=vector[c+1];
                      vector[c+1]=a;
                  }
              }
          }
          
          System.out.println("imprimiendo los numeros");
          
          for (f=1;f<=5;f++)
          {
              System.out.println("posicion fila es: "+f+"es: "+vector[f]);
          }
      }
    
}
