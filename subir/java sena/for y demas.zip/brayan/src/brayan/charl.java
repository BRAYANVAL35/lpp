package brayan;
import java.util.Scanner;
public class charl 
{
    public static void main(String[] args) 
    {
        char l;
        l=' ';
        System.out.println("digite el caracter");
        Scanner lulo=new Scanner(System.in);
        l=lulo.next().charAt(0);
        System.out.println("su caracter es: "+l);
    }
    
}
