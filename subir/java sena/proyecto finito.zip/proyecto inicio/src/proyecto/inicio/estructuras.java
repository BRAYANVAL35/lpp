package proyecto.inicio;
import java.util.Scanner;
public class estructuras 
{
    public static void main(String[] args)
    {
        int edad;
        System.out.println("ingrese su edad \n"); 
        Scanner Entrada=new Scanner(System.in);
        edad=Entrada.nextInt();
        
        if(edad>17)
        {
            System.out.println("ingrese a cine para adultos");
        }
        else
        {
            if(edad>14)
            {
                System.out.println("ingrese a cine para adolescentes");
            }
            else
            {
                System.out.println("ingrese a cine para niños");
            }
        }
    }
    
}
