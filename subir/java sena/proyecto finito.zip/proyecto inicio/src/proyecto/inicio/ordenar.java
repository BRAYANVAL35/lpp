package proyecto.inicio;
import java.util.Scanner;
public class ordenar 
{
    public static void main(String[] args)
    {
        int a,b,c;
        System.out.println("ingrese su edad \n"); 
        Scanner Entrada=new Scanner(System.in);
        System.out.println("ingese el primer numero ");
        a=Entrada.nextInt();
        System.out.println("ingrese el segundo numero");
        b=Entrada.nextInt();
        System.out.println("ingrese el tercer numero");
        c=Entrada.nextInt();
        
        if((a>b)&&(a>c))
        {
            System.out.println("el numero mayor es: "+a);
            System.out.println("el numero del medio es: "+b);
            System.out.println("el numero menor es: "+c);
        }
        else if ((b>a)&&(b>c))
            {
                System.out.println("el numero mayor es: "+b);
                System.out.println("el numero del medio es: "+a);
                System.out.println("el numero menor es: "+c);
            }
         else if ((c>a)&&(c>b))
            {
                System.out.println("el numero mayor es: "+c);
                System.out.println("el numero del medio es: "+b);
                System.out.println("el numero menor es: "+a);
            }
    }   
}
