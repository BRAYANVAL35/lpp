package proyecto.inicio;
import java.util.Scanner;
public class ingresandoDatos 
{
    public static void main(String[] args)
    {
        int n1,n2,n3,s1,r1,r2,r3,s2,s3,m1,m2,m3,resultado;
        double d1,d2,d3;
        Scanner Entrada=new Scanner(System.in);
        System.out.println("ingrese los numeros para la suma \n");
        System.out.println("ingrese el primer numero");
        n1=Entrada.nextInt();
        System.out.println("ingrese el primer numero");
        n2=Entrada.nextInt();
        resultado=n1+n2;
        System.out.println("el resulado de la suma es: "+resultado);
        
        System.out.println("ingrese los numeros para la resta \n");
        System.out.println("ingrese el primer numero");
        r1=Entrada.nextInt();
        System.out.println("ingrese el primer numero");
        r2=Entrada.nextInt();
        r3=r1-r2;
        System.out.println("el resulado de la resta es: "+r3);
        
        System.out.println("ingrese los numeros para la multiplicacion \n");
        System.out.println("ingrese el primer numero");
        m1=Entrada.nextInt();
        System.out.println("ingrese el primer numero");
        m2=Entrada.nextInt();
        m3=m1*m2;
        System.out.println("el resulado de la multiplicacion es: "+resultado);
        
        System.out.println("ingrese los numeros para division \n");
        System.out.println("ingrese el primer numero");
        d1=Entrada.nextDouble();
        System.out.println("ingrese el primer numero");
        d2=Entrada.nextDouble();
        d3=d1/d2;
        System.out.println("el resulado de la division es: "+d3);
        
        byte numero=127;
        long numero1=33333;
        int numero2=2147483647;
        short numero3=32767;
        double numero4=999999999;
        float numero5=999999999;
        
        System.out.println("en numero byte es:"+numero);
        System.out.println("en numero long es:"+numero1);
        System.out.println("en numero int es:"+numero2);
        System.out.println("en numero short es:"+numero3);
        System.out.println("en numero double es:"+numero4);
        System.out.println("en numero float es:"+numero5);


    }
}